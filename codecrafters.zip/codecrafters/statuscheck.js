// Example data (you can replace it with your actual data)
const reports = [
    {
        id: 1,
        subject: "Issue with website loading",
        date: "2024-04-01",
        priority: "High",
        department: "IT",
        status: "Pending"
    },
    {
        id: 2,
        subject: "Email not sending",
        date: "2024-03-30",
        priority: "Medium",
        department: "Support",
        status: "In Progress"
    },
    {
        id: 3,
        subject: "Login problem",
        date: "2024-03-28",
        priority: "Low",
        department: "Customer Service",
        status: "Resolved"
    }
];

// Function to display reports
function displayReports() {
    const statusContainer = document.getElementById("statusContainer");
    statusContainer.innerHTML = ""; // Clear previous content

    reports.forEach(report => {
        const ticket = document.createElement("div");
        ticket.classList.add("ticket");

        const ticketInfo = document.createElement("div");
        ticketInfo.classList.add("ticket-info");
        ticketInfo.innerHTML = `
            <span>Ticket ID: ${report.id}</span>
            <span>Date: ${report.date}</span>
        `;
        ticket.appendChild(ticketInfo);

        const statusButtons = document.createElement("div");
        statusButtons.classList.add("status-buttons");
        const status = document.createElement("span");
        status.classList.add("ticket-status", report.status.toLowerCase().replace(" ", "-"));
        status.textContent = report.status;
        statusButtons.appendChild(status);
        ticket.appendChild(statusButtons);

        const subject = document.createElement("div");
        subject.textContent = 'Subject: ' + report.subject;
        ticket.appendChild(subject);

        const priority = document.createElement("div");
        priority.textContent = 'Priority: ' + report.priority;
        ticket.appendChild(priority);

        const department = document.createElement("div");
        department.textContent = 'Department: ' + report.department;
        ticket.appendChild(department);

        statusContainer.appendChild(ticket);
    });
}

// Display reports when the page loads
document.addEventListener("DOMContentLoaded", displayReports);