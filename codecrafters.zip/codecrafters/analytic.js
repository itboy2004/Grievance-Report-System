// Sample data (replace with actual data)
const data = {
  totalUsers: 1000,
  totalComplaints: 500,
  complaintsSolved: 400,
  inProgress: 50,
  pending: 50
};

// Function to update dashboard with data
function updateDashboard(data) {
  document.getElementById('resolveRate').textContent = `${((data.complaintsSolved / data.totalComplaints) * 100).toFixed(2)}%`;

  const pendingRate = ((data.pending / data.totalComplaints) * 100).toFixed(2);
  document.getElementById('pendingRate').textContent = `${pendingRate}%`;

  const inProgressRate = ((data.inProgress / data.totalComplaints) * 100).toFixed(2);
  document.getElementById('inProgressRate').textContent = `${inProgressRate}%`;

  const ctx = document.getElementById('dashboardChart').getContext('2d');
  const chart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Total Users', 'Total Complaints', 'Complaints Solved', 'In Progress', 'Pending'],
      datasets: [{
        label: 'Metrics',
        data: [data.totalUsers, data.totalComplaints, data.complaintsSolved, data.inProgress, data.pending],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
        ],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
}

// Call updateDashboard with sample data
updateDashboard(data);
